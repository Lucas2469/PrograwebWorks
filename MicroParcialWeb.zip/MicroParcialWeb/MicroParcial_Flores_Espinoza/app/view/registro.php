
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuarios</title>
<link rel="stylesheet" href="../../public/css/style.css">
</head>
<body>
    <div class="register-form">
        <h2>Registro de Usuarios</h2>
        <form action="../controller/UsuarioController.php" method="post">

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email"  placeholder="Email" required>
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" name="password"  placeholder="Contraseña" required>
            </div>
            <div class="form-group">
                <label for="password">Confirmar Contraseña</label>
                <input type="password" name="confirmPassword"  placeholder="Confirmar Contraseña" required>
            </div>
            <input type="hidden" name="action" value="registrar">
            <input type="submit" value="Registrarse" class="btn">
        </form>
        <div class="footer">
            <p>¿Ya tienes una cuenta? <a href="login.php">Inicia sesión</a></p>
        </div>
    </div>
</body>
</html>
