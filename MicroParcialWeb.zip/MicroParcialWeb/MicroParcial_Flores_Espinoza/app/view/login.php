<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="../../public/css/style.css">
</head>
<body>
    <div class="login-form">
        <h2>Bienvenido</h2>
        <form action="../controller/UsuarioController.php" method="post">
            <div class="form-group">
                <label for="email">Usuario (Email)</label>
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" name="password" placeholder="Contraseña" required>
            </div>
            <!-- Campo oculto para especificar la acción a realizar -->
            <input type="hidden" name="action" value="login">
            <input type="submit" value="Login" class="btn">
        </form>
        <div class="footer">
            <p>¿No tienes Cuenta? <a href="registro.php">Regístrate</a></p>
        </div>
    </div>
</body>
</html>
