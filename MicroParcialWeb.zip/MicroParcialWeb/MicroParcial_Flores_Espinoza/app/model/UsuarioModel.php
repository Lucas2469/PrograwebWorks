<?php
require_once('../../core/conexion.php');

    /*
        @param $email el nombre del usuario
        @param $password la contrasenia del usuario
    */

class UsuarioModel {
    public function login($email, $password) {
        global $conexion;
        $sql = "SELECT * FROM user WHERE email=? AND password=?";
        $stmt = $conexion->prepare($sql);
        if (!$stmt) {
            die("Error preparando la consulta: " . $conexion->error);
        }
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function registrar($email, $password) {
        global $conexion;
        $sql = "INSERT INTO user (email, password) VALUES (?, ?)";
        $stmt = $conexion->prepare($sql);
        if (!$stmt) {
            die("Error preparando la consulta: " . $conexion->error);
        }
        $stmt->bind_param("ss", $email, $password);
        return $stmt->execute();
    }
}
?>
