<?php
require_once('../model/UsuarioModel.php');

/*
            @param $email el nombre del usuario
            @param $password la contrasenia del usuario
            @param $confirmPassword la contrasenia del usuario, la cual debe repetirse para confirmarse

        */

class UsuarioController {
    public function login($email, $password) {
        $model = new UsuarioModel();
        $usuario = $model->login($email, $password);
        if ($usuario) {
            session_start();
            $_SESSION['usuario'] = $usuario;
            header("Location: ../view/bienvenido.php");
            exit();
        } else {
            echo "Usuario no registrado o contraseña incorrecta";
            // Añade depuración aquí para ver qué pasa
            header("refresh:3;url=../view/login.php");
            exit();  // Asegúrate de llamar a exit() después de una redirección
        }
    }
    
    public function registrar($email, $password, $confirmPassword) {
        if ($password != $confirmPassword) {
            echo "Las contraseñas no coinciden.";
            header("refresh:1;url=../view/registro.php");
            exit();
        }
        $model = new UsuarioModel();
        if ($model->registrar($email, $password)) {
            echo "Usuario registrado exitosamente.";
            header("refresh:1;url=../view/login.php");
        } else {
            echo "Error al registrar usuario.";
        }
    }
}

session_start();

if (isset($_POST['action'])) {
    require_once('UsuarioController.php');
    $controller = new UsuarioController();

    // Añade esto para depurar
    var_dump($_POST);

    if ($_POST['action'] === 'login') {
        $controller->login($_POST['email'], $_POST['password']);
    } elseif ($_POST['action'] === 'registrar') {
        $controller->registrar($_POST['email'], $_POST['password'], $_POST['confirmPassword']);
    }
} else {
    echo "No se ha recibido ninguna acción.";
}

?>
