<?php
$host = "localhost:3307";
$usuario = "root";
$contraseña = "";
$base_de_datos = "login_web";
?>
